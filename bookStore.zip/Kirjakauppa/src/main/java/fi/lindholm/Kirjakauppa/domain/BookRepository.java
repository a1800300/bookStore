package fi.lindholm.Kirjakauppa.domain;

//import java.util.List;
import org.springframework.data.repository.CrudRepository;


//repository needed to use all database functions (create, update, delete) in our program

//crudrepository is a ready JPA interface. Inside <> we define the duties of the interface: What Entity does this BookRepository belong to?
public interface BookRepository extends CrudRepository <Book, Long> {

  //List<Book> findByTitle(String title);

  //<title extends Book> S save(S Book);
	//void deleteById(Long id);



	//Object findAll();

	/*@Repository is a Spring annotation that indicates that the decorated class is a repository. 
	A repository is a mechanism for
	encapsulating storage, retrieval, and search behavior which emulates a collection of objects
*/

  
}
