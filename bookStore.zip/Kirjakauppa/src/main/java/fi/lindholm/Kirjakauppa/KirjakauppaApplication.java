package fi.lindholm.Kirjakauppa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import fi.lindholm.Kirjakauppa.domain.Book;
import fi.lindholm.Kirjakauppa.domain.BookRepository;


@SpringBootApplication
public class KirjakauppaApplication {
	//private static final Logger log = LoggerFactory.getLogger(StudentListApplication.class);
	public static void main(String[] args) {
		SpringApplication.run(KirjakauppaApplication.class, args);
	}


	@Bean
	public CommandLineRunner bookStore(BookRepository repository) {
		return (args) -> {
		//	log.info("save a couple of books");
		
			// Tallennetaan kirjoja valmiiksi tämän komentorivin kautta, jotta ohjelman demoaminen ja muokkaus helpompaa:
	/* Attribuutit: private String isbn,title,author,category; 
	private double price;
	private int year;*/
			
			Book b1 = new Book ("9780441172719","Dune","Herbert, Frank","fiction",12.50,1965);
			Book b2 = new Book ("9789510415344","Lopotti","Kinnunen, Tommi","fiction",26.30,2016);
			Book b3 = new Book ("9789511346524","Becoming","Obama, Michelle","autobiography",21.00,2018);
						
				repository.save(b1);
				repository.save(b2);
				repository.save(b3);
			//log.info("fetch all books");
			//}

		};
	}
}

