package fi.lindholm.Kirjakauppa.web;

//Note! There is no @ResponseBody annotation when using Thymeleaf templates.

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.ui.Model; // public String bookList(Model model)
/*import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMethod;*/

import fi.lindholm.Kirjakauppa.domain.Book;
//import fi.lindholm.Bookstore.domain.Book;
import fi.lindholm.Kirjakauppa.domain.BookRepository;


@Controller
public class BookController {
	@Autowired /*annotation bring repository class into the context, and
	will inject an instance of the service into the YourAppClass class.*/
	// to access the books in your database, inject repository clalss to your controller class.
	private BookRepository repository; 
	
	
 @RequestMapping(value= {"/booklist"})
 public String bookList(Model model) {
 	// send all books to a view. This is achieved with model.
     model.addAttribute("books", repository.findAll()); // ("key","all books from database")
     return "booklist"; // name of the view
 }

 @RequestMapping(value = "/add") // in addbook.html there is a button that listens this endpoint
	public String addBook(Model model){
 	model.addAttribute("book", new Book());
     return "addbook"; // goes to addbook.html
 }     
 
 @RequestMapping(value = "/save", method = RequestMethod.POST) // addbook needs a submit endpoint /save
 public String save(Book book){
     repository.save(book);
     return "redirect:booklist"; // goes to booklist.html
 } 
 

 @RequestMapping(value = "/delete/{id}", method = RequestMethod.GET) //{id} is the path variable. you can delete by localhost/8080/idnumber
 public String deleteBook(@PathVariable("id") Long BookId, Model model) { // saves it to the variable BookId
 	repository.deleteById(BookId);
     return "redirect:../booklist";
 }     
}



//In a typical Spring application, Controller classes are responsible for
//preparing a model map with data and selecting a view to be rendered.


